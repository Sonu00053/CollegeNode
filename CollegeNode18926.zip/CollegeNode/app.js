require('dotenv').config();

global.CONSTANTS = require('./constants/constant');
global.Form = require('./helpers/FormHelper');
global.SuperHelper = require('./helpers/superHelper');
const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');

const session = require("express-session");



const app = express();

// ============================
// BODY PARSERS
// ============================
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
// app.use(session({
//     secret: "college-secret",
//     resave: false,
//     saveUninitialized: true
// }));

app.use(session({
    secret: "college-secret",
    resave: false,
    saveUninitialized: true,
    cookie: {
        maxAge: 24 * 60 * 60 * 1000 // 1 day
    }
}));

// ============================
// COOKIE PARSER
// ============================
app.use(cookieParser());

// ============================
// STATIC FILES
// ============================
app.use(express.static(path.join(__dirname, 'views')));

// ============================
// ROUTES
// ============================
const adminRoutes = require('./routes/admin');
const superRoutes = require('./routes/super');
const mainroute = require('./routes/route');
const userroute = require('./routes/roles');
app.use('/admin', adminRoutes);
app.use('/super', superRoutes);
app.use(CONSTANTS.role, userroute);
app.use('/', mainroute);

// ============================
// 404 HANDLER
// ============================
app.use((req, res) => {
    res.status(404).send('404 - Page Not Found');
});

module.exports = app;